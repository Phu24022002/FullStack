-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mer 22 Novembre 2023 à 21:32
-- Version du serveur: 5.0.51
-- Version de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `muctieucanhan`
--

-- --------------------------------------------------------

--
-- Structure de la table `3muctieuthang`
--

CREATE TABLE `3muctieuthang` (
  `id` int(11) NOT NULL auto_increment,
  `muctieu1` varchar(500) collate utf8_unicode_ci NOT NULL,
  `muctieu2` varchar(500) collate utf8_unicode_ci NOT NULL,
  `muctieu3` varchar(500) collate utf8_unicode_ci NOT NULL,
  `thoigian` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `3muctieuthang`
--


-- --------------------------------------------------------

--
-- Structure de la table `camxuc`
--

CREATE TABLE `camxuc` (
  `id` int(11) NOT NULL auto_increment,
  `tencamxuc` varchar(500) collate utf8_unicode_ci NOT NULL,
  `ngay` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Contenu de la table `camxuc`
--

INSERT INTO `camxuc` (`id`, `tencamxuc`, `ngay`) VALUES
(16, 'giận dữ', '2023-11-18');

-- --------------------------------------------------------

--
-- Structure de la table `dieubieton`
--

CREATE TABLE `dieubieton` (
  `id` int(11) NOT NULL auto_increment,
  `noiDung` text collate utf8_unicode_ci NOT NULL,
  `thoiGian` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Contenu de la table `dieubieton`
--

INSERT INTO `dieubieton` (`id`, `noiDung`, `thoiGian`) VALUES
(1, 'alloo', '2023-11-17'),
(9, 'chơi game', '2023-11-18'),
(10, 'Quốc test th1', '2023-01-18');

-- --------------------------------------------------------

--
-- Structure de la table `muctieuthang`
--

CREATE TABLE `muctieuthang` (
  `id` int(11) NOT NULL auto_increment,
  `habit_name` varchar(500) collate utf8_unicode_ci NOT NULL,
  `completed_days` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `date_ht` varchar(500) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Contenu de la table `muctieuthang`
--

INSERT INTO `muctieuthang` (`id`, `habit_name`, `completed_days`, `created_at`, `date_ht`) VALUES
(7, 'chơi game 30p ', 4, '2023-11-15', '    0 15 17 19 22'),
(8, 'đánh răng 10p', 3, '2023-11-15', '   0 15 18'),
(12, 'Đọc sách 30p', 2, '2023-11-15', '  0 17'),
(13, 'Đá bóng 1h', 1, '2023-11-18', ' 0 18');

-- --------------------------------------------------------

--
-- Structure de la table `nhinlai`
--

CREATE TABLE `nhinlai` (
  `id` int(11) NOT NULL auto_increment,
  `than` text collate utf8_unicode_ci NOT NULL,
  `tam` text collate utf8_unicode_ci NOT NULL,
  `tri` text collate utf8_unicode_ci NOT NULL,
  `thoiGian` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Contenu de la table `nhinlai`
--

INSERT INTO `nhinlai` (`id`, `than`, `tam`, `tri`, `thoiGian`) VALUES
(1, 'ưqe', 'qewe', 'qưeq', '2023-10-23'),
(2, 'w', 're', 'ử', '2023-09-23'),
(3, 'moi ne', 'ne', 'ji', '2023-03-10'),
(4, 'hgfd', 'feq', 'eqweq', '2023-08-16'),
(17, 'fsfsf', 'ădfff', 'affaf', '2023-11-18'),
(18, '12222222', '222222', '22222', '2023-11-18'),
(19, 'quan tron ', 'hgerfed', 'hgfd', '2023-11-19'),
(20, 'quoix', 'hgerfed', 'hgfd', '2023-11-19');

-- --------------------------------------------------------

--
-- Structure de la table `notes`
--

CREATE TABLE `notes` (
  `id` int(11) NOT NULL auto_increment,
  `date` date default NULL,
  `note` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Contenu de la table `notes`
--

INSERT INTO `notes` (`id`, `date`, `note`) VALUES
(10, '2023-11-30', 'hello'),
(14, '2023-11-08', 'ngày 8 ăn cơm'),
(15, '2023-11-09', 'chào ngày 9'),
(16, '2023-11-22', 'thi cuối kỳ'),
(17, '2023-11-08', 'đi chơi với ghệ');

-- --------------------------------------------------------

--
-- Structure de la table `viecquantrongcanlam`
--

CREATE TABLE `viecquantrongcanlam` (
  `id` int(20) NOT NULL auto_increment,
  `noiDung` text collate utf8_unicode_ci NOT NULL,
  `mucDoUTien` int(11) NOT NULL,
  `ghiChu` int(20) NOT NULL,
  `thoiGian` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

--
-- Contenu de la table `viecquantrongcanlam`
--

INSERT INTO `viecquantrongcanlam` (`id`, `noiDung`, `mucDoUTien`, `ghiChu`, `thoiGian`) VALUES
(1, 'Nghe Nhạc 30p', 2, 15, '2023-11-15'),
(2, 'Ngủ Trưa', 1, 15, '2023-11-15'),
(3, 'Câu cá', 5, 15, '2023-11-15'),
(9, 'Tập Thể Dục', 1, 16, '2023-11-16'),
(10, 'ngủ trưa', 5, 16, '2023-11-16'),
(11, 'chơi game', 2, 16, '2023-11-16'),
(16, 'nghe nhạc 30p', 2, 16, '2023-11-16'),
(17, 'đi chơi vui vẻ', 1, 16, '2023-11-16'),
(18, 'ngủ trưa', 5, 16, '2023-11-16'),
(20, '12 giờ học', 22, 16, '2023-11-16'),
(24, '4', 4, 16, '2023-11-16'),
(25, 'ngủ trưa', 1, 16, '2023-11-16'),
(26, 'chơi game', 1, 17, '2023-11-17'),
(27, 'ngủ trưa', 2, 17, '2023-11-17'),
(28, 'ăn 3 bữa', 2, 18, '2023-11-18'),
(29, 'uống 2 ly trà sữa', 1, 18, '2023-11-18'),
(30, 'hgfds', 2, 19, '2023-11-19'),
(31, 'jhgfds', 3, 0, '2023-11-19'),
(32, 'chơi game', 11, 22, '2023-11-22');
